import Login from "../../components/Login";

const Home = () => {
    return (
        <div className="homepage">
            <Login />
        </div>
    )
}

export default Home; 